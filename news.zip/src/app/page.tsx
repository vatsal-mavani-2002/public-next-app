"use client";
import NewsFeed from "@/components/NewsFeed/page";
import "../i18n";

export default function Home() {
  return <NewsFeed />;
}
